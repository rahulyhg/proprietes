<?php get_header() ?>

<section class="i-section">
	<div class="container c1 wcc">
		<div class="content-area row the-page-content">
			<div class="col-md-12">
				<?php woocommerce_content() ?>
			</div>
		</div>
	</div>
</section>

<?php get_footer() ?>