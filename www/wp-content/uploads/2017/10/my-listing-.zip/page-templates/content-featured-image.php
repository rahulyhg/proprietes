<?php
/**
 * Template Name: Content + Full Width Featured Image
 */

get_header(); the_post(); ?>

	<?php get_template_part('partials/content', 'single') ?>

<?php get_footer();