<?php
	// Silence is golden.