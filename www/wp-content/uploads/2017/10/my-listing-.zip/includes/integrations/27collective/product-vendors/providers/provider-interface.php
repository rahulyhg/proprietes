<?php

namespace CASE27\Integrations\ProductVendors;

interface ProviderInterface {
	public function activate();
}