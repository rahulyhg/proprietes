<?php do_action( 'case27_woocommerce_account_listings_before' ) ?>

<?php echo do_shortcode('[job_dashboard]') ?>

<?php do_action( 'case27_woocommerce_account_listings_after' ) ?>
