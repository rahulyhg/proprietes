<?php
	// WIP: WC Product Vendors integration