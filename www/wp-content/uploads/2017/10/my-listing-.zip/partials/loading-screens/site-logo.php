<div class="loader-bg main-loader site-logo-loader" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_background_color' ,'#ffffff' ) ) ?>;">
	<img src="<?php echo esc_url( c27()->get_site_logo() ) ?>">
</div>