<div class="loader-bg main-loader background-color" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_background_color' ,'#ffffff' ) ) ?>;">
	<div class="sk-double-bounce">
		<div class="sk-child sk-double-bounce1" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#ffffff' ) ) ?>;"></div>
		<div class="sk-child sk-double-bounce2" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#ffffff' ) ) ?>;"></div>
	</div>
</div>