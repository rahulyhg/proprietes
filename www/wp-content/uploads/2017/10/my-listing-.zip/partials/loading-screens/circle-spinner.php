<div class="loader-bg main-loader border-color" style="background-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_background_color' ,'#ffffff' ) ) ?>;">
	<div class="spin-box" style="
		border-color: transparent;
		border-bottom-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;
		border-left-color: <?php echo esc_attr( c27()->get_setting( 'general_loading_overlay_color' ,'#000000' ) ) ?>;
	"></div>
</div>